import { createFileRoute } from '@tanstack/react-router';
import { useEffect, useState } from 'react';
import { ArrowUpRight, MapPin, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Countdown, ScratchDate } from '@/components/invitation-interactions';
import couple from '@/assets/couple.png';
import curtain from '@/assets/curtain-backdrop.jpg';
import flowers from '@/assets/floral-corner.png';

export const Route = createFileRoute('/')({
  head: () => ({ meta: [
    { title: 'Usama & Kiran — A Nikah Invitation' },
    { name: 'description', content: 'You are cordially invited to the Nikah of Usama Aamir and Kiran Arooj, Friday October 30, 2026 at Bin Fida Palace Marquee.' },
    { property: 'og:title', content: 'Usama & Kiran — A Nikah Invitation' },
    { property: 'og:description', content: 'Join us in celebrating the Nikah of Usama Aamir and Kiran Arooj on October 30, 2026.' },
    { property: 'og:type', content: 'website' },
    { name: 'twitter:card', content: 'summary_large_image' },
  ] }),
  component: Index,
});

function Ornament({ className = '' }: { className?: string }) {
  return <div className={`ornament ${className}`} aria-hidden="true"><span /><i>✧</i><span /></div>;
}

function Index() {
  const [guest, setGuest] = useState('Honored Guest & Family');
  const [phase, setPhase] = useState<'sealed' | 'opening' | 'open' | 'closing'>('sealed');
  useEffect(() => {
    const name = new URLSearchParams(window.location.search).get('guest')?.trim();
    if (name) setGuest(name);
  }, []);
  useEffect(() => {
    if (phase !== 'opening' && phase !== 'closing') return;
    const timer = window.setTimeout(() => setPhase(phase === 'opening' ? 'open' : 'sealed'), window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 100 : phase === 'opening' ? 3200 : 1700);
    return () => window.clearTimeout(timer);
  }, [phase]);
  useEffect(() => {
    if (phase === 'open') return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = previous; };
  }, [phase]);

  return <div className={`wedding-app phase-${phase}`}>
    <img className="scene-backdrop" src={curtain} alt="" width={1536} height={1024} />
    <header className="invitation-header"><span>U <i>&</i> K</span><span>A CELEBRATION OF LOVE & FAITH</span><span>30 · 10 · 26</span></header>
    <main className="invitation-main" inert={phase !== 'open'} aria-hidden={phase !== 'open'}>
      <article className="invitation-paper">
        <div className="paper-border" aria-hidden="true" />
        <img className="floral floral-top" src={flowers} alt="" width={1024} height={1024} />
        <img className="floral floral-top-left" src={flowers} alt="" width={1024} height={1024} />
        <img className="floral floral-bottom" src={flowers} alt="" width={1024} height={1024} loading="lazy" />
        <img className="floral floral-bottom-right" src={flowers} alt="" width={1024} height={1024} loading="lazy" />
        <section className="couple-section">
          <p className="bismillah" lang="ar" dir="rtl">بِسْمِ اللهِ الرَّحْمٰنِ الرَّحِيْمِ</p>
          <p className="verse">“And We created you in pairs”</p>
          <p className="verse-source">SURAH AN-NABA · 78:8</p>
          <Ornament />
          <p className="eyebrow">THE NIKAH CELEBRATION OF</p>
          <h1 className="couple-names"><span>Usama Aamir</span><small>Son of Mr. & Mrs. M. Aamir</small><i>&</i><span>Kiran Arooj</span><small>Daughter of Mr. & Mrs. Mobeen Akhtar</small></h1>
          <img className="couple-portrait" src={couple} alt="Bride and Groom" width={746} height={1127} />
          <div className="guest-dedication"><p>Cordially request the honour of the presence of</p><strong>{guest}</strong><p>as they begin their forever, Insha’Allah.</p></div>
        </section>
        <section className="date-section">
          <Ornament />
          <p className="eyebrow">A BEAUTIFUL BEGINNING</p>
          <h2>Save the Date</h2>
          <ScratchDate />
          <div className="formal-date"><span>FRIDAY</span><strong>30</strong><span>OCTOBER<br />2026</span></div>
          <p className="time-note">AT THREE O’CLOCK IN THE AFTERNOON · PKT</p>
        </section>
        <section className="venue-section">
          <MapPin className="venue-icon" strokeWidth={1} aria-hidden="true" />
          <p className="eyebrow">THE VENUE</p><h2>Bin Fida Palace Marquee</h2>
          <Button asChild variant="outline" className="maps-button"><a href="https://www.google.com/maps/search/?api=1&query=Bin+Fida+Palace+Marquee" target="_blank" rel="noopener noreferrer"><MapPin size={14} />Open in Google Maps<ArrowUpRight size={14} /></a></Button>
        </section>
        <section className="events-section"><Ornament /><h2>Order of Events</h2><div className="event-timeline">{[['03:00 PM', 'Arrival'], ['04:00 PM', 'Nikkah'], ['05:00 PM', 'Lunch']].map(([time, title]) => <div className="event" key={title}><span className="event-dot" /><time>{time}</time><h3>{title}</h3></div>)}</div></section>
        <section className="countdown-section"><p className="eyebrow">UNTIL OUR FOREVER BEGINS</p><Countdown /><Ornament /><p className="closing-line">Two hearts. One beautiful beginning.</p><p className="closing-monogram">U <i>&</i> K</p></section>
      </article>
      <footer className="invitation-footer"><span>WITH LOVE, USAMA & KIRAN</span><Button variant="ghost" size="icon" aria-label="Replay invitation opening" title="Replay invitation opening" onClick={() => { window.scrollTo({ top: 0, behavior: 'instant' }); setPhase('closing'); }}><RotateCcw size={15} /></Button></footer>
    </main>
    <div className="opening-screen" inert={phase === 'open' || phase === 'closing'} aria-hidden={phase === 'open' || phase === 'closing'}>
      <div className="curtain-panel curtain-left" aria-hidden="true" /><div className="curtain-panel curtain-right" aria-hidden="true" />
      <div className="opening-content">
        <p className="opening-eyebrow">IN THE NAME OF ALLAH, THE MOST MERCIFUL</p>
        <div className="opening-monogram">U <i>&</i> K</div>
        <Ornament />
        <p className="opening-title">A little envelope.<br /><em>A lifetime of love.</em></p>
        <div className="envelope-stage"><div className="envelope"><div className="envelope-lining" /><div className="envelope-folds" /><div className="envelope-flap" /><div className="envelope-lines" /><div className="envelope-inscription">Usama <i>&</i> Kiran</div><Button className="wax-seal" aria-label="Tap to break seal and open invitation" disabled={phase === 'opening'} onClick={() => setPhase('opening')}><span className="seal-ring"><span className="seal-monogram">U<span>&</span>K</span><span className="seal-label">TAP TO<br />BREAK SEAL</span></span></Button></div></div>
        <div className="opening-guest"><span>Specially Invited For:</span><strong>{guest}</strong></div>
        <p className="opening-date">THE NIKAH · OCTOBER 30, 2026</p>
      </div>
      <span className="opening-footnote">AN INVITATION TO OUR BEAUTIFUL BEGINNING</span>
    </div>
  </div>;
}
