import { useEffect, useRef, useState, type PointerEvent } from 'react';
import { Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';

const weddingTime = Date.parse('2026-10-30T15:00:00+05:00');

export function Countdown() {
  const [remaining, setRemaining] = useState<number | null>(null);
  useEffect(() => {
    const update = () => setRemaining(Math.max(0, weddingTime - Date.now()));
    update();
    const timer = window.setInterval(update, 1000);
    return () => window.clearInterval(timer);
  }, []);
  const seconds = remaining === null ? null : Math.floor(remaining / 1000);
  const values = seconds === null ? ['—', '—', '—', '—'] : [Math.floor(seconds / 86400), Math.floor(seconds / 3600) % 24, Math.floor(seconds / 60) % 60, seconds % 60].map(value => String(value).padStart(2, '0'));
  return <div className="countdown" aria-label="Countdown to the Nikah">
    {['Days', 'Hours', 'Minutes', 'Seconds'].map((label, index) => <div key={label} className="countdown-unit"><span className="countdown-number">{values[index]}</span><span className="countdown-label">{label}</span></div>)}
  </div>;
}

export function ScratchDate() {
  const canvas = useRef<HTMLCanvasElement>(null);
  const lastPoint = useRef<{ x: number; y: number } | null>(null);
  const [revealed, setRevealed] = useState(false);
  useEffect(() => {
    const element = canvas.current;
    if (!element || revealed) return;
    const paint = () => {
      const rect = element.getBoundingClientRect();
      const ratio = Math.min(window.devicePixelRatio || 1, 2);
      element.width = rect.width * ratio;
      element.height = rect.height * ratio;
      const context = element.getContext('2d', { willReadFrequently: true });
      if (!context) return;
      context.scale(ratio, ratio);
      const styles = getComputedStyle(element);
      const gold = styles.getPropertyValue('--primary').trim();
      const light = styles.getPropertyValue('--gold-light').trim();
      const dark = styles.getPropertyValue('--gold-deep').trim();
      const gradient = context.createLinearGradient(0, 0, rect.width, rect.height);
      gradient.addColorStop(0, light); gradient.addColorStop(0.38, gold); gradient.addColorStop(0.65, light); gradient.addColorStop(1, gold);
      context.fillStyle = gradient;
      context.fillRect(0, 0, rect.width, rect.height);
      context.globalAlpha = 0.14;
      for (let x = 0; x < rect.width; x += 4) for (let y = 0; y < rect.height; y += 4) {
        context.fillStyle = (x + y) % 12 === 0 ? dark : light;
        context.fillRect(x, y, 1, 2);
      }
      context.globalAlpha = 1;
      context.fillStyle = dark;
      context.textAlign = 'center';
      context.font = '500 11px Montserrat, sans-serif';
      context.fillText('✦ Scratch with finger to reveal the date ✦', rect.width / 2, rect.height / 2 + 4);
    };
    paint();
    const observer = new ResizeObserver(paint);
    observer.observe(element);
    return () => observer.disconnect();
  }, [revealed]);

  const scratch = (event: PointerEvent<HTMLCanvasElement>) => {
    if (!lastPoint.current) return;
    const element = event.currentTarget;
    const context = element.getContext('2d', { willReadFrequently: true });
    if (!context) return;
    const bounds = element.getBoundingClientRect();
    const point = { x: event.clientX - bounds.left, y: event.clientY - bounds.top };
    context.globalCompositeOperation = 'destination-out';
    context.lineWidth = 36; context.lineCap = 'round'; context.lineJoin = 'round';
    context.beginPath(); context.moveTo(lastPoint.current.x, lastPoint.current.y); context.lineTo(point.x, point.y); context.stroke();
    lastPoint.current = point;
  };
  const finish = () => {
    lastPoint.current = null;
    const element = canvas.current;
    const context = element?.getContext('2d', { willReadFrequently: true });
    if (!element || !context) return;
    const pixels = context.getImageData(0, 0, element.width, element.height).data;
    let clear = 0; let total = 0;
    for (let i = 3; i < pixels.length; i += 64) { total++; if ((pixels[i] ?? 255) < 128) clear++; }
    if (clear / total > 0.38) setRevealed(true);
  };
  return <div className="scratch-wrap">
    <div className="scratch-card">
      <div className="revealed-date" aria-live="polite"><span>FRIDAY, OCTOBER 30, 2026</span><span>• 03:00 PM •</span></div>
      {!revealed && <canvas ref={canvas} aria-label="Scratch with finger to reveal the date" onPointerDown={event => { event.currentTarget.setPointerCapture(event.pointerId); const rect = event.currentTarget.getBoundingClientRect(); lastPoint.current = { x: event.clientX - rect.left, y: event.clientY - rect.top }; scratch(event); }} onPointerMove={scratch} onPointerUp={finish} onPointerCancel={finish} />}
    </div>
    {!revealed && <Button variant="ghost" size="icon" className="scratch-accessible" aria-label="Reveal the date without scratching" title="Reveal the date" onClick={() => setRevealed(true)}><Sparkles /></Button>}
  </div>;
}